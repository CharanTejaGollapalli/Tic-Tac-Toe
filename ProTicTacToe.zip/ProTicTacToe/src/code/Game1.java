package code;
//Up to switching the player but result need to implement with the choosen player
//Default players is okay
import java.util.Scanner;

public class Game1 {

	public static void main(String[] args) {
		
		String board[][] = new String[3][3];
		String firstPlayer = "X";
		String secondPlayer = "O";
		Scanner s = new Scanner(System.in);
		System.out.print("If you want to select your own Players Enter Yes : ");
		String select1=s.nextLine();
		String select=select1.toUpperCase();
		if (select.equals("YES") || select.equals("YE") || select.equals("Y")) {
			System.out.print("Choose Player 1 : ");
			firstPlayer = s.nextLine();
			System.out.print("Choose Player 2 : ");
			secondPlayer = s.nextLine();
			System.out.println("Player 1 is '" + firstPlayer + "' & Player 2 is '" + secondPlayer + "'");
		} else {
			System.out.println("By default the Player 1 is 'X' & Player 2 is 'O'");
		}
		System.out.println("Who want's to start first");
		System.out
				.println("Choose 1 if Player 1 want's to start first or Choose 2 if Player 2 want's to play first : ");
		String curruntPlayer=firstPlayer;
		int choose = s.nextInt();
		if (choose == 1) {
			curruntPlayer = firstPlayer;
			System.out.println("Player 1 is starting the game");
		} else if (choose == 2) {
			curruntPlayer = secondPlayer;
			System.out.println("Player 2 is starting the game");
		} else {
			System.out.println("You Choose wrong player by default the Player 1 " + firstPlayer + " will start first");
			curruntPlayer = firstPlayer;
		}
		int l=(firstPlayer.length()>secondPlayer.length()) ? firstPlayer.length() : secondPlayer.length();
		String elementWithDefaultLength="";
		for(int i=0;i<l;i++) {
			elementWithDefaultLength+=" ";
		}
		initializationOfEmptyBoard(board, elementWithDefaultLength);
//		initialBoard(board);
		System.out.println("Start the Game!!!");
		display(board,l);
		boolean tf = true;
//		while (empty(board,elementWithDefaultLength)) {
		while (empty(board, elementWithDefaultLength)) {
			int first =-1;
			int second =-1;
			try {
				System.out.print("Enter player " + curruntPlayer + " :");
				first = s.nextInt();
				second = s.nextInt();
				if (board[first][second] ==elementWithDefaultLength) {
					if((first<3 && first>=0) && (second<3 && second>=0))
					board[first][second] = curruntPlayer;
					else 
						System.out.println("Choose Correct indexes from 0, 1 or 2");
					
				} else {
					curruntPlayer = (curruntPlayer == firstPlayer) ? secondPlayer : firstPlayer;
					System.out.println("Player " + curruntPlayer + " choosen this cell already choose another");
				}
		} catch (Exception e) {
			System.out.println("Choose Correct indexes from 0, 1 or 2");
		}
				display(board,l);
				if(checkWin(board, curruntPlayer)) {
					System.out.print("If yoy want to play again Press 0 or press anything to Exit :");
					int restart=restart(s,board,l,elementWithDefaultLength);
					if (restart != 0) {
						System.out.println("Game End.");
						break;
					}
				}
				curruntPlayer = (curruntPlayer == firstPlayer) ? secondPlayer : firstPlayer;
			if (!empty(board,elementWithDefaultLength)) {
				System.out.println("Game Tie");
				System.out.print("If yoy want to restart Press 0 or Press anything to End and Exit :");
				int restart=restart(s,board,l,elementWithDefaultLength);
				if (restart != 0) {
					System.out.println("Game End.");
					break;
				}

			}

		}

	}
	private static int restart(Scanner s,String[][] board,int l,String elementWithDefaultLength) {
		int restart = s.nextInt();
		if (restart == 0) {
			System.out.println("The game restarted, Start Playing");
//			initialBoard(b,l);
			initializationOfEmptyBoard(board, elementWithDefaultLength);
			System.out.println("Start the Game!!!");
			display(board,l);
		} 
		return restart;
	}
	public static void initializationOfEmptyBoard(String[][] board,String elementWithDefaultLength) {
		for (int row = 0; row < board.length; row++) {
			for (int col = 0; col < board[row].length; col++) {
				board[row][col] =elementWithDefaultLength;
			}
		}	
	}
	public static void initialBoard(String[][] a,int l) {
		for (int row = 0; row < a.length; row++) {
			for (int col = 0; col < a[row].length; col++) {
				a[row][col]="";
				for(int i=0;i<l;i++) {
				a[row][col] +=" ";
				}
			}
		}	
	}

	public static boolean checkWin(String[][] b, String cf) {
		for (int row = 0; row < b.length; row++) {
			if (b[row][0] == cf && b[row][1] == cf && b[row][2] == cf) {
				System.out.println("Player " + cf + " won, game over.");
				return true;
			}
		}
		for (int col = 0; col < b.length; col++) {
			if (b[0][col] == cf && b[1][col] == cf && b[2][col] == cf) {
				System.out.println("Player " + cf + " won, game over.");
				return true;
			}

		}
		if (b[0][0] == cf && b[1][1] == cf && b[2][2] == cf) {
			System.out.println("Player " + cf + " won, game over.");
			return true;
		}
		if (b[0][2] == cf && b[1][1] == cf && b[2][0] == cf) {
			System.out.println("Player " + cf + " won, game over.");
			return true;
		}
		return false;

	}

	public static boolean empty(String[][] b,String elementWithDefaultLength) {
		for (int col = 0; col < b.length; col++) {
			for (int row = 0; row < b.length; row++) {
				if (b[col][row] == elementWithDefaultLength) {
					return true;
				}
			}
		}
		return false;
	}

//	public static void display(String[][] b) {
//		for (int row = 0; row < b.length; row++) {
//			for (int col = 0; col < b[row].length; col++) {
//				System.out.print(b[row][col] + " |");
//			}
//			System.out.println();
//		}
//	}
	public static void display(String[][] a,int l) {
		for (int row = 0; row < a.length; row++) {
			for (int col = 0; col < a[row].length; col++) {
				int le=Math.abs(l-a[row][col].length());
					for(int i=0;i<le;i++) {
						a[row][col]+=" ";
					}
				System.out.print(a[row][col] + " |");
			}
			System.out.println();
		}
	}
}
